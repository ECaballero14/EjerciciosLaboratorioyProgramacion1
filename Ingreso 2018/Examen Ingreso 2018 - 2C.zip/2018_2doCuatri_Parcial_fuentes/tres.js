function mostrar()
{
	alert("comentar esta linea 3");
}
