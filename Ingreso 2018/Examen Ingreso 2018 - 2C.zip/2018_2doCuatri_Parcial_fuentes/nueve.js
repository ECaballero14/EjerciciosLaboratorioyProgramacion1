function mostrar()
{
	alert("comentar esta linea 9");
}
