unsigned int verifica(void);
