import React, { Component } from "react";
import Menu from "../components/Menu/MenuContainer";

class MenuC extends Component {



    render() {



        return (
            <div>
                <Menu />

            </div>
        )
    }
}

export default MenuC;